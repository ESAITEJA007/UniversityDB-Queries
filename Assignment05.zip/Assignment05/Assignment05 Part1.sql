/*
// Name : Saiteja Enimidigandla
// Student ID: 999902573
// Student ID Name : SEnimidigandla3555
*/

-- Displaying databases --
show databases;

-- Using database named test  --
use test;

/*DROP tables customer,tape,movie,director,star,played;*/

-- Creating customer table with following fields --

CREATE TABLE `customer` (
  `number` int NOT NULL,
  `name` varchar(30) NOT NULL,
  `address` varchar(40) NOT NULL,
  `date` date NOT NULL,
  `number_of_rentals` int NOT NULL,
  `bonus` int NOT NULL
);

-- Creating tape table with following fields --

CREATE TABLE `tape` (
  `code` int NOT NULL,
  `purchase_date` date NOT NULL,
  `times_rented` int NOT NULL,
  `c_number` int DEFAULT NULL,
  `m_number` int DEFAULT NULL
);

-- Creating movie table with following fields --


CREATE TABLE `movie` (
  `number` int NOT NULL,
  `title` int NOT NULL,
  `year` int NOT NULL,
  `type` int NOT NULL,
  `critic_rating` int NOT NULL,
  `nominations` int NOT NULL,
  `award_won` int NOT NULL,
  `d_number` int DEFAULT NULL
);

-- Creating director table with following fields --

CREATE TABLE `director` (
  `name` varchar(30) NOT NULL,
  `number` int NOT NULL,
  `year_of_birth` date NOT NULL,
  `year_of_death` date NOT NULL
);

-- Creating star table with following fields --


CREATE TABLE `star` (
  `number` int NOT NULL,
  `name` varchar(30) NOT NULL,
  `birth_place` varchar(40) NOT NULL,
  `year_of_birth` date NOT NULL,
  `year_of_death` date NOT NULL
); 

-- Creating played table with following fields --


CREATE TABLE `played` (
  `s_number` int DEFAULT NULL,
  `m_number` int DEFAULT NULL,
  `role` varchar(30) NOT NULL
);

-- creating number as primary key for the customer table. --

ALTER TABLE `customer`
  ADD PRIMARY KEY (`number`);

-- Declaring autoincrement for the primary key number of customer table --
ALTER TABLE `customer`
  MODIFY `number` int NOT NULL AUTO_INCREMENT;
  
-- Creating code as primary key for the tape table and keys --


ALTER TABLE `tape`
  ADD PRIMARY KEY (`code`),
  ADD KEY `rented` (`c_number`),
  ADD KEY `contains` (`m_number`);
 
-- Creating number as primary key for the star table --

ALTER TABLE `star`
  ADD PRIMARY KEY (`number`);
  
-- creating number of movie table as a primary key and a key --
 
ALTER TABLE `movie`
  ADD PRIMARY KEY (`number`),
  ADD KEY `directed_by` (`d_number`);
 
 -- creating number of director table as a primary key and keys --

  ALTER TABLE `director`
  ADD PRIMARY KEY (`number`);

-- Adding keys for the played table --
ALTER TABLE `played`
  ADD KEY `star_play` (`s_number`),
  ADD KEY `movie_play` (`m_number`);

-- setting foreign key d_number of director number --
ALTER TABLE `movie`
  ADD CONSTRAINT `directed_by` FOREIGN KEY (`d_number`) REFERENCES `director` (`number`) ON DELETE SET NULL ON UPDATE CASCADE;

-- setting constraints c number, d number of director number on delete on update cascade --

ALTER TABLE `tape`
  ADD CONSTRAINT `contains` FOREIGN KEY (`m_number`) REFERENCES `movie` (`number`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `rented` FOREIGN KEY (`c_number`) REFERENCES `customer` (`number`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

-- setting constraints key m number, s number of director number on delete on update cascade --


ALTER TABLE `played`
  ADD CONSTRAINT `movie_played` FOREIGN KEY (`m_number`) REFERENCES `movie` (`number`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `star_played` FOREIGN KEY (`s_number`) REFERENCES `star` (`number`) ON DELETE SET NULL ON UPDATE CASCADE;

SHOW TABLES;

-- insert one row into each table --

INSERT INTO customer values(103,"Saiteja Enimidigandla","Arkansas",DATE '2022-12-17',21,2000);

INSERT INTO director values('Anderson',544,DATE '1967-12-17',DATE '2021-12-17');

INSERT INTO star values(322,"Jeff","Magnolia",DATE '1952-12-17',DATE '2019-12-17');

INSERT INTO movie values(526,"Thrones",1987,1,5,10,12,544);

INSERT INTO tape values(591,DATE '1993-12-17',10,103,526);

INSERT INTO played values(322,526,"Action");


select * from played;