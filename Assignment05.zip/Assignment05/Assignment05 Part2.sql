/*
// Name : Saiteja Enimidigandla
// Student ID: 999902573
// Student ID Name : SEnimidigandla3555
*/
-- using company database --
show databases;

use company;


show tables;
-- 01.  names of employees who work on the ‘ProductZ’ project -- 
Select E.fname, E.lname
from Employee as E, works_On as W, Project as P
where E.ssn=W.essn and W.pno=P.pnumber and P.pname='ProductZ';

-- 02. names of employees that works for ‘Administration’ department -- 

Select fname,lname
from Employee, Department
where dno=dnumber and dname='Administration';

-- 03.salary of all male employees who works for ‘Administration’ department --

Select salary
from Employee, Department
where sex='M' and dno=dnumber and dname='Administration';

-- 04.names of department managers whose last name is ‘Wong’; -- 

Select fname,lname
from Employee
where ssn in (select mgrssn from department)
and lname like 'W%';

-- 05.names and addresses of employees who work least one project located in  Stafford.  --

Select distinct E.fname, E.lname, E.address
from Employee as E, works_On as W, Project as P
where E.ssn=W.essn and W.pno=P.pnumber and P.plocation='Stafford';

-- 06.names of employees who have has dependents and is supervised by 'FranklinWong'. --

Select  distinct fname,lname
from Employee
where superssn in (select ssn from employee where fname='Franklin' and lname='Wong')
and ssn in (select essn from Dependent);

-- 07.names of female employees who have dependents  --
Select distinct E.lname
from Employee as E, Dependent as D
where E.ssn=D.essn and E.sex='F';

-- 08. Inserting a new Project “ProductXX”, with pnumber 40, located at Dallas, controll by department 5 --
Insert into project (`PNAME`, `PNUMBER`, `PLOCATION`, `DNUM`) 
values ('ProductXX', 40, 'Dallas', 5);

-- 09.Updating Project ProductXX so it will be contrleed by department 4 --

Update project 
set DNUM=4
where pnumber='4' ;

-- 10.Deleting project 40 from the table project --

Delete from project
where pnumber='40';